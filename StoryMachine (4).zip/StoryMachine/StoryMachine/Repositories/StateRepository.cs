﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoryMachine.DatabaseModels;

namespace StoryMachine.Repositories
{
    class StateRepository
    {

        public bool AddState(State State)
        {
            return true;
        }

        public bool DeleteState(State State)
        {
            return true;
        }

        public bool UpdateState(State State)
        {
            return true;
        }

        public State GetStateById(int id)
        {
            return null;
        }

        public List<State> GetAllStories()
        {
            return null;
        }










    }
}
