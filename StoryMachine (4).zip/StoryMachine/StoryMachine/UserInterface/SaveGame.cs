﻿namespace StoryMachine.UserInterface
{
    internal class SaveGame
    {
    }
}