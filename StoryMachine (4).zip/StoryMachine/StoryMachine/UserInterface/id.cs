﻿namespace StoryMachine.UserInterface
{
    internal class id
    {
    }
}