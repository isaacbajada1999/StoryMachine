﻿namespace StoryMachine.UserInterface
{
    internal class option1
    {
    }
}