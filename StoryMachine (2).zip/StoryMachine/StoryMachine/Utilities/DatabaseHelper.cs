﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using StoryMachine.DatabaseModels;

namespace StoryMachine.Utilities
{
    class DatabaseHelper
    {
        public NpgsqlConnection conn;

        public DatabaseHelper()
        {
            conn = new NpgsqlConnection("Server=127.0.0.1;User Id=postgres; " +
                        "Password=postgres;Database=Assignment;Search Path=public");
            conn.Open();
        }


        public string QueryValue(string statment)
        {

            // Define a query returning a single row result set
            NpgsqlCommand command = new NpgsqlCommand(statment, conn);
            NpgsqlDataReader dataReader = command.ExecuteReader();
            String text = "";
            while (dataReader.Read())
            {
                text = dataReader[0].ToString();

            }
            return text;
        }



        public string[] Query(string statment)
        {

            // Define a query returning a single row result set
            NpgsqlCommand command = new NpgsqlCommand(statment, conn);
            NpgsqlDataReader dataReader = command.ExecuteReader();
            var listofOptions = new List<Option>;
            while (dataReader.Read())
            {
                var option = new Option();
                option.optionnames = dataReader[0].ToString();
                listofOptions.Add(option);
               // text = dataReader[0].ToString();

            }
            //return listofOptions;
        }


        public Int64 Count(string tableName)
        {

            // Define a query returning a single row result set
            NpgsqlCommand command = new NpgsqlCommand($"SELECT COUNT(*) FROM \"{tableName.ToLower()}\"", conn);
            // Execute the query and obtain the value of the first column of the first row
            Int64 count = (Int64)command.ExecuteScalar();

            return count;
        }
        
        public void CloseConnection()
        {
            conn.Close();
        }
    }
}
