﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoryMachine.DatabaseModels
{
    public class Option
    {
        public int passage_id { get; set; }
        public string optionnames { get; set; }
        public int requiredOption_id { get; set; }
        public int destPassage_id { get; set; }
    }
}
