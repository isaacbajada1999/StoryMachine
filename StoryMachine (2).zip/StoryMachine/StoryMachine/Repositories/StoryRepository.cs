﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoryMachine.DatabaseModels;

namespace StoryMachine.Repositories
{
    class StoryRepository
    {
        List<Story> stories = new List<Story>
        {
            new Story() {story = "Baywatch", id = 0},
            new Story() {story = "Sherlock", id = 1}
        };

        public bool AddStory(Story story)
        {
            return true;
        }

        public bool DeleteStory(Story story)
        {
            return true;
        }

        public bool UpdateStory(Story story)
        {
            return true;
        }

        public Story GetStoryById(int id)
        {
            return stories.Where(story => story.id == id).FirstOrDefault();
        }

        public Story GetStoryByName(string name)
        {
            return stories.Where(story => story.story == name).FirstOrDefault();
        }

        public List<Story> GetAllStories()
        {
            return stories;
        }


    }
}
