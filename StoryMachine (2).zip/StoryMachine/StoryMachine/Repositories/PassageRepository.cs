﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoryMachine.DatabaseModels;

namespace StoryMachine.Repositories
{
    class PassageRepository
    {
        List<Passage> passages = new List<Passage>
        {
            new Passage {  Id = 0, StoryId = 0, Title = "Computer document", Description = "You are in a libery of a shcool and theres a computer that is currently on and it has a document someone was working on it also looks like it has been turnd on for a while. What do you do?" },
            new Passage {  Id = 1, StoryId = 1, Title = "Computer document Discovery", Description = "You look closer at the computer and it looks like the document is a test plan for a application that someone was developing. What do you do?." }, 
          new Passage { Id = 2, StoryId = 0, Title = "computer error", Description = "You are in a shcool class room on your own and there is a computer that is giving a error and it looks like no one has been using that comptuer in a while. What do you do?." },
          new Passage { Id = 3, StoryId = 0, Title = "Computer login ", Description ="You are in a study room of a shcool and there is computer that is showing a login screen for the computer. What do you do? " },
          new Passage { Id = 4, StoryId = 0, Title = "computer problem", Description ="You are in a room in a shcool that is filled with computers and you go to one of them to work on and it dosent turn on for you. What do you do?" },
          new Passage { Id = 5, StoryId = 0, Title = "NO internet", Description ="You are in a shcool class room working on your personal computer and you go on the internet and serach for infomation and you find out that there is no internet connection. What do you do?" },
            new Passage { Id = 6, StoryId = 0, Title = "printer", Description ="You are in a class room in a shcool and there is a printer that is printing from a computer that no one is using. What do you do?" },
              new Passage { Id = 7, StoryId = 0, Title = "Printer papers discovery", Description ="you look closer at the papers being printed and you notise that someones project of shcool is being printed withoth anyone monitering it. What do you do?" },
                new Passage { Id = 8, StoryId = 0, Title = "slow laptop", Description ="You are in a shcool office and they give you a laptop to use and when you turn it on it starts to slow down. what do you do?" },
                  new Passage { Id = 9, StoryId = 0, Title = "computer burning CD", Description ="You are in a shcool class room and there is a computer that is burning a CD but it looks like there hasent been any one on the computer for a while. What do you do?" }
        };



        public bool AddPassage(Passage Passage)
        {
            return true;
        }

        public bool DeletePassage(Passage Passage)
        {
            return true;
        }

        public bool UpdatePassage(Passage Passage)
        {
            return true;
        }

        public Passage GetPassageById(int id)
        {
            return null;
        }

        public List<Passage> GetAllPassages()
        {
            return passages;
        }

        public List<Passage> GetAllPassagesByStoryId(int storyId)
        {
            return GetAllPassages().Where(passage => passage.StoryId == storyId).ToList();
        }


    }
}
