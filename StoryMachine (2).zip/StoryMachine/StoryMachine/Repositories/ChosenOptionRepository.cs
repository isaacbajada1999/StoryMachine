﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoryMachine.DatabaseModels;

namespace StoryMachine.Repositories
{
    class ChosenOptionRepository
    {

        public bool AddChosenOption(ChosenOption ChosenOption)
        {
            return true;
        }

        public bool DeleteChosenOption(ChosenOption ChosenOption)
        {
            return true;
        }

        public bool UpdateChosenOption(ChosenOption ChosenOption)
        {
            return true;
        }

        public ChosenOption GetChosenOptionByStateId(int stateId)
        {
            return null;
        }

        public ChosenOption GetChosenOptionByOptionId(int optionId)
        {
            return null;
        }

        public List<ChosenOption> GetAllStories()
        {
            return null;
        }







    }
}
